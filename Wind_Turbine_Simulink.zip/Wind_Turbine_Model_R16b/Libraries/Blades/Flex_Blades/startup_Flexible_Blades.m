%STARTUP FLEXIBLE BLADES
addpath(pwd);
addpath([pwd '\Scripts']);
addpath([pwd '\Images']);
addpath([pwd '\Libraries']);

load ss_cantilever_pva
Flexible_Cantilever_Lumped_Parameters
Flex_Blades_Params

Wind_Turbine_Flexible_Blades

% Copyright 2009-2016 The MathWorks(TM), Inc.
