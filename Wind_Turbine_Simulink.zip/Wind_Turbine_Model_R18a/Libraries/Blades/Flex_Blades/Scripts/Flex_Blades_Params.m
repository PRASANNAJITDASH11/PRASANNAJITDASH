Flex_Blade.Kp = 0.5;
Flex_Blade.Ki = 0.5;
Flex_Blade.Damping = 1;

% Copyright 2009-2018 The MathWorks(TM), Inc.
