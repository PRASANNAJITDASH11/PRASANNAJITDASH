pip3.6 install requests
pip3.6 install wakeonlan
pip3.6 install AWSIoTPythonSDK